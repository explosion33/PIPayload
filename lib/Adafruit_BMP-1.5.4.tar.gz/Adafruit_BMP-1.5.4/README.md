DEPRECATED LIBRARY Adafruit Python BMP
===================

This library has been deprecated!

the bmp085 and bmp180 are no longer made, and are replaced by the bmp280 + friends

we are now only using our circuitpython sensor libraries in python

we are leaving the code up for historical/research purposes but archiving the repository.

check out this guide for using the bmp280 with python!
https://learn.adafruit.com/adafruit-bmp280-barometric-pressure-plus-temperature-sensor-breakout








Adafruit Python BMP
------------------------

Python library for accessing the BMP series pressure and temperature sensors like the BMP085/BMP180 on a Raspberry Pi or Beaglebone Black.

Designed specifically to work with the Adafruit BMP085/BMP180 pressure sensors ----> https://www.adafruit.com/products/1603

To install, download the library by clicking the download zip link to the right and unzip the archive somewhere on your Raspberry Pi or Beaglebone Black.  Then execute the following command in the directory of the library:~~

````
sudo python setup.py install
````

Make sure you have internet access on the device so it can download the required dependencies.

See examples of usage in the examples folder.

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by Tony DiCola for Adafruit Industries.
MIT license, all text above must be included in any redistribution
